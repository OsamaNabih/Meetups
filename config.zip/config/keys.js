module.exports = {
  JWT_SECRET: 'ThisIsASecretForOurTokens',
  DBconfig: {
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'tafrah'
  },
  oauth: {
    facebook: {
      clientID: '159993988033091',
      clientSecret: '94a23e95abcca3f197f9d6c858939e66'
    },
    google: {
      clientID: '835631524663-b6nhvpmsbpndqa8g4m051r5qd4iujgjt.apps.googleusercontent.com',
      clientSecret: 'KlCyyv2VcOc07Gzhktkj1RKX'
    }
  }
}
